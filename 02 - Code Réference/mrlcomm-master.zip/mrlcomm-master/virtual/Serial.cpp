/*
 * Serial.cpp
 *
 *  Created on: Nov 3, 2016
 *      Author: gperry
 */

#include "Serial.h"

Serial::Serial() {
	// TODO Auto-generated constructor stub

}

Serial::~Serial() {
	// TODO Auto-generated destructor stub
}

