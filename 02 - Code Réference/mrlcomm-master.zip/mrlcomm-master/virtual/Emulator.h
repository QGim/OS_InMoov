/*
 * Emulator.h
 *
 *  Created on: Nov 3, 2016
 *      Author: gperry
 */

#ifndef VIRTUAL_EMULATOR_H_
#define VIRTUAL_EMULATOR_H_

class Emulator {
public:
	Emulator();
	virtual ~Emulator();
};

#endif /* VIRTUAL_EMULATOR_H_ */
