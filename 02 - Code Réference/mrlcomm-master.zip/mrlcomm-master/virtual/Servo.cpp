/*
 * Servo.cpp
 *
 *  Created on: Nov 3, 2016
 *      Author: gperry
 */

#include "Arduino.h"
#include "Servo.h"

Servo::Servo() {
	// TODO Auto-generated constructor stub

}

Servo::~Servo() {
	// TODO Auto-generated destructor stub
}

