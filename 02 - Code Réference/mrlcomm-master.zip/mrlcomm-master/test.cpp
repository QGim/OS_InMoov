/*
 * test.cpp
 *
 *  Created on: Nov 2, 2016
 *      Author: gperry
 */



#include <iostream>

int main()
{
    std::cout << "Hello, world!\n";
}

